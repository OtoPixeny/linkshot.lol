import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { clerkId } = await req.json()
    
    if (!clerkId) {
      return new Response(
        JSON.stringify({ error: 'clerkId is required' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      )
    }

    // Get Clerk secret key from environment
    const clerkSecretKey = Deno.env.get('CLERK_SECRET_KEY')
    if (!clerkSecretKey) {
      return new Response(
        JSON.stringify({ error: 'Clerk secret key not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      )
    }

    // Fetch user from Clerk API
    const clerkResponse = await fetch(`https://api.clerk.dev/v1/users/${clerkId}`, {
      headers: {
        'Authorization': `Bearer ${clerkSecretKey}`,
        'Content-Type': 'application/json'
      }
    })

    if (!clerkResponse.ok) {
      return new Response(
        JSON.stringify({ error: 'User not found in Clerk' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 404 }
      )
    }

    const user = await clerkResponse.json()
    
    return new Response(
      JSON.stringify({ 
        imageUrl: user.image_url,
        firstName: user.first_name,
        lastName: user.last_name
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})
