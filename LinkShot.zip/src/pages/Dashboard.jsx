import { Label } from "@/components/ui/label"
import ManageForm from '@/components/ManageForm'
import UserPageLink from '@/components/UserPageLink'
import { useUser } from "@clerk/clerk-react"
import { Mail, Calendar } from "lucide-react"
import { useClerkAvatar } from '@/hooks/useClerkAvatar'

export default function Dashboard() {
  const { user } = useUser()
  useClerkAvatar() // This will automatically sync avatar to database
  
  if (!user) {
    return <div>Loading...</div>
  }

  const { imageUrl, firstName, lastName, emailAddresses, createdAt } = user
  const fullName = `${firstName || ''} ${lastName || ''}`.trim() || firstName || 'User'
  const email = emailAddresses[0]?.emailAddress

  return (
    <div>
      <UserPageLink />
      <div className="py-5 px-6 md:px-20 lg:px-32 mb-16">
        <div>
          <div className="flex flex-col items-center justify-center gap-4  mt-10 mb-10 ">
            <div className="relative">
              <img
                className="w-24 h-24 rounded-full"
                src={imageUrl}
                alt={fullName}
              />
            </div>
            
          
            <div className="text-center">
              <Label className="text-sm font-medium">პროფილის ავატარი</Label>
              <p className="text-xs dark:text-gray-400 text-gray-600 mt-1">
                ავატარის შეცვლა შეგიძლიათ{" "}
                <a
                  href="#"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  ნავიგაციაში მოცემული ავატარის დროპ მენიუდან
                </a>
                <span className="text-red-600"> *</span>
              </p>
            </div>
          </div>
          <ManageForm />
        </div>
      </div>
    </div>
  )
}
