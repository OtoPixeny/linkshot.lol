import { Link } from "react-router-dom";
import { Button } from "./ui/button";
import Logo from "./Logo";
import { CornerRightDown } from "lucide-react";
import { ModeToggle } from "./ModeToggle";
import { useUser } from "@clerk/clerk-react";
import { UserButton } from "@clerk/clerk-react";

export default function Header() {
  const { isSignedIn, user } = useUser();
  
  return (
    <header className="flex justify-between items-center py-5 px-6 sm:px-8 md:px-20 lg:px-24">
      <div>
        <Logo />
      </div>
      <div className="flex gap-2 items-center">
        {isSignedIn ? (
          <>
            <Button asChild size="sm">
              <Link
                to="/dashboard/manage"
                className="gap-2"
              >
                სამართავი პანელი
                <CornerRightDown className="!h-4 !w-4" />
              </Link>
            </Button>
            <UserButton 
              appearance={{
                elements: {
                  avatarBox: " !h-8 !w-8 ",
                  userButtonTrigger: "p-0",
                }
              }}
              afterSignOutUrl="/"
            />
          </>
        ) : (
          <Button asChild size="sm">
            <Link
              to="/auth/sign-in"
              className="gap-2"
            >
              დაიწყე ახლავე
              <CornerRightDown className="!h-4 !w-4" />
            </Link>
          </Button>
        )}
        <ModeToggle />
      </div>
    </header>
  );
}
