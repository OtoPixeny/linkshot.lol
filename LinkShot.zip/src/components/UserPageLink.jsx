"use client";

import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useUser } from "@clerk/clerk-react";
import UserModel from "@/models/user";

export default function UserPageLink() {
  const { user } = useUser();
  const [show, setShow] = useState(false);
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");

  useEffect(() => {
    const loadUserData = async () => {
      if (user?.id && !username) {
        try {
          const userData = await UserModel.getByUserId(user.id);
          if (userData) {
            setUsername(userData.username);
            setName(userData.name);
          }
        } catch (error) {
          console.error("Error loading user data:", error);
          // User might not exist yet, that's okay
        } finally {
          setShow(true);
        }
      }
    };

    loadUserData();
  }, [user, username]);

  return (
    <div className="px-6 md:px-20 lg:px-32">
      {show && username && (
        <Alert className="mb-6">
          <AlertTitle>შენი სოციალ ფეიჯი</AlertTitle>
          <AlertDescription>
            თქვენი სოციალ ფეიჯის ბმული:{" "}
            <Link
              to={`/user/${username}`}
              className="text-primary hover:underline font-medium"
            >
              {window.location.origin}/user/{username}
            </Link>
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
