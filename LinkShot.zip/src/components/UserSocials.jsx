import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { Icons } from "@/components/icons";
import UserModel from "../models/user";
import CustomLinkModel from "../models/customLink";
import { Share2, Eye } from "lucide-react";
import { FaCheckCircle } from "react-icons/fa";
import Footer from "./Footer";
import { useAuth } from "@/hooks/useAuth";
import { UserAvatar } from "@/components/user-avatar";

// Lazy load icons only when needed
const getIcon = (iconName) => {
  return Icons[iconName] || Icons.globe;
};

export default function UserSocials({ userDataName }) {
  const [loading, setLoading] = useState(true);
  const { user, isSignedIn } = useAuth();

  const [image, setImage] = useState("");
  const [bio, setBio] = useState("");
  const [name, setName] = useState("");

  const [links, setLinks] = useState([]);
  const [customLinks, setCustomLinks] = useState([]);
  const [notFound, setNotFound] = useState(false);

  const [showPrivate, setShowPrivate] = useState(false);
  const [inputKey, setInputKey] = useState("");
  const [error, setError] = useState(false);
  const [accessError, setAccessError] = useState(false);
  const [views, setViews] = useState(0);

  const handleInput = () => {
    if (!inputKey) return;

    if (inputKey === links?.accessKey) {
      setShowPrivate(true);
      setAccessError(false);
    } else {
      setAccessError(true);
      setShowPrivate(false);
    }
  };

  useEffect(() => {
    let username = userDataName;
    const loadUserData = async () => {
      try {
        const userData = await UserModel.getByUsername(username);
        setLoading(false);
        if (userData) {
          console.log('User data received:', userData);
          console.log('Image URL:', userData.image);
          setImage(userData.image);
          setName(userData.name);
          setBio(userData.bio);
          setLinks(userData);
          setViews(userData.views || 0);
          
          // Load custom links
          const customLinksData = await CustomLinkModel.getByUsername(username);
          setCustomLinks(customLinksData || []);
          
          // Increment views in background without blocking UI
          setTimeout(() => {
            UserModel.incrementViews(username).catch(error => {
              console.error('Error incrementing views:', error);
            });
          }, 100);
        } else {
          setNotFound(true);
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
        setLoading(false);
        setNotFound(true);
      }
    };

    loadUserData();
  }, [userDataName]);

  const proffesional = [
    "linkedIn",
    "gitHub",
    "stackoverflow",
    "leetcode",
    "codeforces",
    "hackerrank",
    "codechef",
    "geeksforgeeks",
  ];
  const social = [
    "youtube",
    "instagram",
    "facebook",
    "snapchat",
    "twitter",
    "threads",
    "reddit",
  ];
  const creative = ["twitch", "soundcloud", "spotify", "apple music"];
  const messaging = ["discord", "telegram", "whatsapp", "skype"];
  const storefront = [
    "amazon storefront",
    "shopify",
    "ko-fi",
    "buy me a coffee",
    "patreon",
  ];
  const miscellaneous = ["website", "blog", "email", "phone"];

  const generateSocialUrl = (platform, username) => {
    if (!username || typeof username !== "string") return "";
    
    const cleanUsername = username.trim();
    
    // If already a full URL, return as is
    if (cleanUsername.startsWith("http://") || cleanUsername.startsWith("https://")) {
      return cleanUsername;
    }
    
    // Generate URLs based on platform
    const urlPatterns = {
      instagram: `https://instagram.com/${cleanUsername}`,
      facebook: `https://facebook.com/${cleanUsername}`,
      twitter: `https://twitter.com/${cleanUsername}`,
      threads: `https://threads.net/${cleanUsername}`,
      youtube: `https://youtube.com/${cleanUsername}`,
      snapchat: `https://snapchat.com/add/${cleanUsername}`,
      reddit: `https://reddit.com/user/${cleanUsername}`,
      linkedIn: `https://linkedin.com/in/${cleanUsername}`,
      gitHub: `https://github.com/${cleanUsername}`,
      stackoverflow: `https://stackoverflow.com/users/${cleanUsername}`,
      leetcode: `https://leetcode.com/${cleanUsername}`,
      codeforces: `https://codeforces.com/profile/${cleanUsername}`,
      hackerrank: `https://hackerrank.com/${cleanUsername}`,
      codechef: `https://codechef.com/users/${cleanUsername}`,
      geeksforgeeks: `https://auth.geeksforgeeks.org/user/${cleanUsername}`,
      twitch: `https://twitch.tv/${cleanUsername}`,
      soundcloud: `https://soundcloud.com/${cleanUsername}`,
      spotify: cleanUsername.includes("spotify.com") ? cleanUsername : `https://open.spotify.com/user/${cleanUsername}`,
      "apple music": cleanUsername.includes("music.apple.com") ? cleanUsername : `https://music.apple.com/profile/${cleanUsername}`,
      discord: cleanUsername.includes("discord.gg") ? cleanUsername : `https://discord.com/users/${cleanUsername}`,
      telegram: cleanUsername.includes("t.me") ? cleanUsername : `https://t.me/${cleanUsername}`,
      whatsapp: cleanUsername.includes("wa.me") ? cleanUsername : `https://wa.me/${cleanUsername}`,
      skype: cleanUsername.includes("skype:") ? cleanUsername : `skype:${cleanUsername}?chat`,
      amazon: cleanUsername.includes("amazon.com") ? cleanUsername : `https://amazon.com/stores/${cleanUsername}`,
      shopify: cleanUsername.includes("shopify.com") ? cleanUsername : `https://${cleanUsername}.myshopify.com`,
      "ko-fi": cleanUsername.includes("ko-fi.com") ? cleanUsername : `https://ko-fi.com/${cleanUsername}`,
      "buy me a coffee": cleanUsername.includes("buymeacoffee.com") ? cleanUsername : `https://buymeacoffee.com/${cleanUsername}`,
      patreon: cleanUsername.includes("patreon.com") ? cleanUsername : `https://patreon.com/${cleanUsername}`,
      website: cleanUsername.startsWith("http") ? cleanUsername : `https://${cleanUsername}`,
      blog: cleanUsername.startsWith("http") ? cleanUsername : `https://${cleanUsername}`,
      email: cleanUsername.includes("@") ? cleanUsername : `mailto:${cleanUsername}`,
      phone: cleanUsername.startsWith("+") || /^\d+$/.test(cleanUsername) ? `tel:${cleanUsername}` : cleanUsername
    };
    
    return urlPatterns[platform] || cleanUsername;
  };

  return (
    <div className="relative overflow-x-hidden px-6 md:px-20 lg:px-32 py-20 grid place-content-center">
      <div className="absolute top-0 z-[-2] h-screen w-screen dark:bg-neutral-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))]"></div>
      <div className="fixed top-5 right-5 md:top-10 md:right-32 flex gap-2">
        <div className="flex items-center gap-2 bg-background/80 backdrop-blur-sm px-3 py-2 rounded-full border">
          <Eye className="w-4 h-4" />
          <span className="text-sm font-medium">{views}</span>
        </div>
        <div
          onClick={() => {
            navigator.share({ url: window.location.href, title: name, text: name });
          }}
        >
          <Button
            variant="pulseBtn"
            className="w-10 h-10 rounded-full p-0 flex items-center justify-center"
          >
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
      <div className="grid place-content-center mb-5 mt-14">
        {loading && <Skeleton className="h-24 w-24 rounded-full" />}
        
        {!loading && isSignedIn && user && (
          <div className="w-24 h-24 rounded-full overflow-hidden">
            <UserAvatar 
              user={user} 
              className="w-full h-full object-cover"
              fallbackClassName="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-3xl font-bold"
            />
          </div>
        )}
        
        {!loading && (!isSignedIn || !user) && (
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-3xl font-bold">
            {name ? name.charAt(0).toUpperCase() : '?'}
          </div>
        )}
      </div>
      <div className="grid place-content-center mb-6 text-center gap-3 px-2">
        <h1 className="text-3xl font-bold flex justify-center items-center text-center">
          {name}
          {name && <FaCheckCircle className="!h-4 !w-4 opacity-50 ml-2" />}
        </h1>

        <p className="text-base dark:text-gray-400 text-foreground/80 max-w-[320px] mx-auto sm:line-clamp-2 line-clamp-none">
          {bio?.length > 70 ? bio.slice(0, 70) : bio || "Welcome to my social links page!"}
        </p>
      </div>

      {loading && <Skeleton className="h-8 mb-5 w-40 mx-auto" />}
      {loading && <Skeleton className="h-14 mb-5 w-[300px] mx-auto" />}

      {loading && (
        <div className="grid gap-3 max-w-[600px]">
          <Skeleton className="h-14 w-[300px] mx-auto" />
          <Skeleton className="h-14 w-[300px] mx-auto" />
          <Skeleton className="h-14 w-[300px] mx-auto" />
          <Skeleton className="h-14 w-[300px] mx-auto" />
        </div>
      )}

      {!loading && (
        <div className="grid mt-10 gap-3">
          {Object.entries(links || {})
            .filter(([key, value]) => social.includes(key) && value && typeof value === "string" && value.trim() !== "")
            .map(([key, value]) => {
              const Icon = getIcon(key);
              return (
                <Button
                  key={key}
                  asChild
                  variant="outline"
                  className="w-full max-w-[420px] mx-auto justify-start gap-3 h-14"
                >
                  <a href={generateSocialUrl(key, value)} target="_blank" rel="noopener noreferrer">
                    {Icon && <Icon className="w-5 h-5" />}
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </a>
                </Button>
              );
            })}
          {Object.entries(links || {})
            .filter(([key, value]) => proffesional.includes(key) && value && typeof value === "string" && value.trim() !== "")
            .map(([key, value]) => {
              const Icon = getIcon(key);
              return (
                <Button
                  key={key}
                  asChild
                  variant="outline"
                  className="w-full max-w-[420px] mx-auto justify-start gap-3 h-14"
                >
                  <a href={generateSocialUrl(key, value)} target="_blank" rel="noopener noreferrer">
                    {Icon && <Icon className="w-5 h-5" />}
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </a>
                </Button>
              );
            })}
          {Object.entries(links || {})
            .filter(([key, value]) => creative.includes(key) && value && typeof value === "string" && value.trim() !== "")
            .map(([key, value]) => {
              const Icon = getIcon(key);
              return (
                <Button
                  key={key}
                  asChild
                  variant="outline"
                  className="w-full max-w-[420px] mx-auto justify-start gap-3 h-14"
                >
                  <a href={generateSocialUrl(key, value)} target="_blank" rel="noopener noreferrer">
                    {Icon && <Icon className="w-5 h-5" />}
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </a>
                </Button>
              );
            })}
          {Object.entries(links || {})
            .filter(([key, value]) => messaging.includes(key) && value && typeof value === "string" && value.trim() !== "")
            .map(([key, value]) => {
              const Icon = getIcon(key);
              return (
                <Button
                  key={key}
                  asChild
                  variant="outline"
                  className="w-full max-w-[420px] mx-auto justify-start gap-3 h-14"
                >
                  <a href={generateSocialUrl(key, value)} target="_blank" rel="noopener noreferrer">
                    {Icon && <Icon className="w-5 h-5" />}
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </a>
                </Button>
              );
            })}
          {Object.entries(links || {})
            .filter(([key, value]) => storefront.includes(key) && value && typeof value === "string" && value.trim() !== "")
            .map(([key, value]) => {
              const Icon = getIcon(key);
              return (
                <Button
                  key={key}
                  asChild
                  variant="outline"
                  className="w-full max-w-[420px] mx-auto justify-start gap-3 h-14"
                >
                  <a href={generateSocialUrl(key, value)} target="_blank" rel="noopener noreferrer">
                    {Icon && <Icon className="w-5 h-5" />}
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </a>
                </Button>
              );
            })}
          
          {/* Custom Links */}
          {customLinks.map((link) => {
            const Icon = getIcon(link.icon);
            return (
              <Button
                key={link.id}
                asChild
                variant="outline"
                className="w-full max-w-[420px] mx-auto justify-start gap-3 h-14"
              >
                <a href={link.url.startsWith('http') ? link.url : `https://${link.url}`} target="_blank" rel="noopener noreferrer">
                  {Icon && <Icon className="w-5 h-5" />}
                  {link.title}
                </a>
              </Button>
            );
          })}

          {links?.accessKey && (
            <div className="border mt-10 px-4 py-3 rounded-lg mx-auto max-w-[420px]">
              <p className="text-sm text-foreground/80 mb-2">Private Links</p>
              <div className="flex items-center gap-2">
                <Input
                  value={inputKey}
                  onChange={(e) => setInputKey(e.target.value)}
                  placeholder="Enter Access Key"
                />
                <Button onClick={handleInput}>Unlock</Button>
              </div>
              {accessError && (
                <p className="text-red-500 text-sm mt-2">Invalid Access Key</p>
              )}
              {showPrivate && (
                <div className="mt-4 grid gap-3">
                  {Object.entries(links || {})
                    .filter(([key, value]) => miscellaneous.includes(key) && value && (typeof value === "string" || typeof value === "number") && String(value).trim() !== "")
                    .map(([key, value]) => {
                      const Icon = getIcon(key);
                      return (
                        <Button
                          key={key}
                          asChild
                          variant="outline"
                          className="w-full max-w-[420px] mx-auto justify-start gap-3 h-12"
                        >
                          <a href={generateSocialUrl(key, String(value))} target="_blank" rel="noopener noreferrer">
                            {Icon && <Icon className="w-5 h-5" />}
                            {key.charAt(0).toUpperCase() + key.slice(1)}
                          </a>
                        </Button>
                      );
                    })}
                </div>
              )}
            </div>
          )}
        </div>
      )}
      {error && (
        <div className="-mt-20 mb-20 grid place-content-center">
          <h1 className="font-bold text-center text-3xl mt-5">
            მომხმარებელი არ მოიძებნა<span className="text-blue-600">!</span>
          </h1>
          <p className="text-center text-sm mt-2">
            გთხოვთ შეამოწმოთ სახელი <br /> და სცადეთ თავიდან
          </p>
          <Button
            href="/"
            className="mt-5 w-full max-w-sm mx-auto"
          >
            უკან დაბრუნება
          </Button>
        </div>
      )}
    </div>
  );
}
