import { supabase, createSupabaseClientWithToken } from '@/lib/supabase'

// Map database column names to frontend field names
const columnMapping = {
  github: 'gitHub',
  linkedin: 'linkedIn',
  "apple music": 'apple music',
  amazon: 'amazon',
  "ko-fi": 'ko-fi',
  "buy me a coffee": 'buy me a coffee',
  geeksforgeeks: 'geeksforgeeks',
  accesskey: 'accessKey', // Handle lowercase accesskey
  accessKey: 'accessKey' // Handle camelCase accessKey
};

// Helper function to map database data to frontend format
const mapDataToFrontend = (data) => {
  if (!data) return data;
  
  const mappedData = {};
  Object.keys(data).forEach(key => {
    const mappedKey = columnMapping[key] || key;
    mappedData[mappedKey] = data[key];
  });
  
  return mappedData;
};

export class UserModel {
  static async getByUserId(userId) {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle()
      
      if (error) {
        console.error('Error fetching user by ID:', error)
        throw error
      }
      
      return mapDataToFrontend(data)
    } catch (error) {
      console.error('Supabase error:', error.message)
      throw error
    }
  }

  static async getByClerkId(clerkId) {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('clerk_id', clerkId)
        .maybeSingle()
      
      if (error) {
        console.error('Error fetching user by Clerk ID:', error)
        throw error
      }
      
      return mapDataToFrontend(data)
    } catch (error) {
      console.error('Supabase error:', error.message)
      throw error
    }
  }

  static async getByUsername(username) {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('username', username)
        .maybeSingle()
      
      if (error) {
        console.error('Error fetching user by username:', error)
        throw error
      }
      
      return mapDataToFrontend(data)
    } catch (error) {
      console.error('Supabase error:', error.message)
      throw error
    }
  }

  static async create(userData) {
    try {
      // If user has clerk_id, try to get their avatar URL from Clerk
      if (userData.clerk_id) {
        try {
          // Store the clerk_id for later avatar fetching
          console.log('Creating user with clerk_id:', userData.clerk_id);
        } catch (error) {
          console.log('Could not fetch Clerk avatar during user creation:', error);
        }
      }
      
      const { data, error } = await supabase
        .from('users')
        .insert([userData])
        .select()
        .maybeSingle()
      
      if (error) {
        console.error('Error creating user:', error)
        throw error
      }
      
      return mapDataToFrontend(data)
    } catch (error) {
      console.error('Supabase error:', error.message)
      throw error
    }
  }

  // Update user's avatar image from Clerk
  static async updateClerkAvatar(clerkId, imageUrl) {
    try {
      const { data, error } = await supabase
        .from('users')
        .update({ image: imageUrl })
        .eq('clerk_id', clerkId)
        .select()
        .maybeSingle()
      
      if (error) {
        console.error('Error updating Clerk avatar:', error)
        throw error
      }
      
      return mapDataToFrontend(data)
    } catch (error) {
      console.error('Supabase error:', error.message)
      throw error
    }
  }

  // Get user by clerk_id and update their avatar if needed
  static async getAndUpdateAvatar(clerkId) {
    try {
      // First get the user
      const user = await this.getByClerkId(clerkId)
      if (!user) {
        return null
      }
      
      return user
    } catch (error) {
      console.error('Error getting user for avatar update:', error)
      throw error
    }
  }

  static async incrementViews(username) {
    try {
      // First try the RPC function, if it fails, fall back to direct update
      let updatedViews;
      
      try {
        const { data, error } = await supabase.rpc('increment_user_views', { 
          user_username: username 
        });
        
        if (error) throw error;
        updatedViews = data;
      } catch (rpcError) {
        console.warn('RPC function failed, falling back to direct update:', rpcError.message);
        
        // Fallback: get current views and update directly
        const { data: userData } = await supabase
          .from('users')
          .select('views')
          .eq('username', username)
          .single();
          
        const currentViews = userData?.views || 0;
        const { data: updatedData } = await supabase
          .from('users')
          .update({ views: currentViews + 1 })
          .eq('username', username)
          .select('views')
          .single();
          
        updatedViews = updatedData?.views || currentViews + 1;
      }
      
      return updatedViews;
    } catch (error) {
      console.error('Error incrementing views:', error);
      throw error;
    }
  }

  static async update(userId, updateData, clerkToken = null) {
    try {
      // Use regular client since RLS is disabled
      const client = supabase;
      
      // First check if user exists
      const existingUser = await client
        .from('users')
        .select('id')
        .eq('clerk_id', userId)
        .maybeSingle();
      
      if (existingUser.error) {
        console.error('Error checking existing user:', existingUser.error);
        throw existingUser.error;
      }
      
      // Map frontend field names to actual database column names
      const mappedData = {};
      Object.keys(updateData).forEach(key => {
        // Reverse mapping: from frontend to database
        const dbColumn = Object.keys(columnMapping).find(dbKey => columnMapping[dbKey] === key) || key;
        mappedData[dbColumn] = updateData[key];
      });

      // Remove accessKey from updateData to avoid column conflicts
      const { accesskey, 'accessKey': accessKeyCamel, ...dataToUpdate } = mappedData;
      
      console.log("Final data to update:", dataToUpdate);
      
      let result;
      if (existingUser.data) {
        // User exists, update them
        const { data, error } = await client
          .from('users')
          .update(dataToUpdate)
          .eq('clerk_id', userId)
          .select()
          .single();
        
        if (error) {
          console.error('Error updating user:', error);
          throw error;
        }
        result = data;
      } else {
        // User doesn't exist, create them
        const createData = { clerk_id: userId, ...dataToUpdate };
        const { data, error } = await client
          .from('users')
          .insert([createData])
          .select()
          .single();
        
        if (error) {
          console.error('Error creating user:', error);
          throw error;
        }
        result = data;
      }
      
      return mapDataToFrontend(result);
    } catch (error) {
      console.error('Supabase error:', error.message);
      throw error;
    }
  }
}

export default UserModel
