// Server-side proxy for Clerk API calls
export async function getServerSideProps(context) {
  const { clerkId } = context.query;
  
  if (!clerkId) {
    return { props: { imageUrl: null } };
  }

  try {
    // This would need to be implemented on your backend
    // For now, we'll return a placeholder
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/clerk-avatar/${clerkId}`);
    
    if (!response.ok) {
      return { props: { imageUrl: null } };
    }
    
    const data = await response.json();
    return { props: { imageUrl: data.imageUrl } };
  } catch (error) {
    console.error('Error fetching Clerk avatar:', error);
    return { props: { imageUrl: null } };
  }
}

// Client-side function to get user avatar via API
export async function getUserAvatarFromClerk(clerkId) {
  if (!clerkId) return null;
  
  try {
    // Try multiple Clerk avatar URL patterns
    const patterns = [
      `https://img.clerk.com/avatars/${clerkId}`,
      `https://images.clerk.dev/uploaded/avatar_${clerkId}`,
      `https://api.clerk.dev/v1/users/${clerkId}/avatar`,
      // Try with .jpg extension
      `https://img.clerk.com/avatars/${clerkId}.jpg`,
      `https://images.clerk.dev/uploaded/avatar_${clerkId}.jpg`,
    ];
    
    // Test each pattern
    for (const url of patterns) {
      try {
        const response = await fetch(url, { 
          method: 'HEAD',
          mode: 'no-cors' // This might help with CORS issues
        });
        
        // If we get here, try to load the image
        return url;
      } catch (error) {
        console.log(`Pattern failed: ${url}`);
        continue;
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error getting user avatar:', error);
    return null;
  }
}
