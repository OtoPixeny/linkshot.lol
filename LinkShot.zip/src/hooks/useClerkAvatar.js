import { useEffect } from 'react'
import { useUser } from '@clerk/clerk-react'
import { UserModel } from '@/models/user'

export function useClerkAvatar() {
  const { user } = useUser()

  useEffect(() => {
    if (user) {
      // Update user's avatar in database whenever it changes
      const updateAvatar = async () => {
        try {
          if (user.imageUrl && user.id) {
            console.log('Updating Clerk avatar in database:', user.imageUrl)
            await UserModel.updateClerkAvatar(user.id, user.imageUrl)
          }
        } catch (error) {
          console.error('Error updating avatar in database:', error)
        }
      }

      updateAvatar()
    }
  }, [user?.imageUrl, user?.id])

  return user
}
